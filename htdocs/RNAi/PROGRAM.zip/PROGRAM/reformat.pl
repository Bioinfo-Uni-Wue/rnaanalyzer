#!/usr/bin/perl -w

open (FILE, $ARGV[0]);
open (OUT, ">$ARGV[1]");

while ($l=<FILE>) {
   if ($l=~/>/) {
   	print OUT "XXX\n"
   }
   print OUT $l;
}
print OUT "XXX\n";
