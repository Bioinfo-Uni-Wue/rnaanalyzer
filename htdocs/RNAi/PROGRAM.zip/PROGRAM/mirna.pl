#!/usr/bin/perl -w

#Commandline: mirna.pl inputfile [rt]  #the rt is optional and will remove the temp file for the inputfile if one exists
# Inputfile has to be in the FASTA format, see www.ebi.ac.uk for database files

# This program is the miRNA.pl microRNA-finder. 



use RNA;
$RNA::noLonelyPairs=1;

### intitialization values
$exponent=2; 

$min_en_cutoff=-30;
$fiveprimestartbefore=15; #contains the number of nucl. that will be extracted before the put. matrix seq. for the checking of the 5'stem
$fiveprimeendafter=100;   #    "     "    "     "   "    "    "    "   "       after the first nucl of the put matrix seq.5'stem
$threeprimestartbefore=64;
$threeprimeendafter=100;




##### values #######
$cutoffvalue=0;
$cutoffvalue1=3.05;

@valuesU1=(0.947368421,0.105263158,0.421052632,0.105263158,0.105263158,0.210526316,0.157894737,0.105263158,0.421052632,0.315789474,0.315789474,0.210526316,0.210526316,0.368421053,0.473684211,0.315789474,0.315789474,0.421052632,0.315789474,0.210526316,0.421052632,0.294117647);
@valuesA1=(0,0.631578947,0.157894737,0.263157895,0.631578947,0.105263158,0.578947368,0.315789474,0.263157895,0.210526316,0.315789474,0.368421053,0.421052632,0.157894737,0.157894737,0.421052632,0.263157895,0.473684211,0.210526316,0.105263158,0.210526316,0.176470588);
@valuesC1=(0.052631579,0,0.105263158,0.473684211,0.105263158,0.421052632,0.105263158,0.210526316,0.315789474,0.368421053,0.210526316,0.157894737,0.210526316,0.052631579,0.105263158,0,0.210526316,0,0,0.157894737,0.210526316,0);
@valuesG1=(0,0.263157895,0.315789474,0.157894737,0.157894737,0.263157895,0.157894737,0.368421053,0,0.105263158,0.157894737,0.263157895,0.157894737,0.421052632,0.263157895,0.263157895,0.210526316,0.105263158,0.473684211,0.526315789,0.157894737,0.529411765);

$cutoffvalue2=3.5;
@valuesU2=(0.6,0.4,0,0,0.6,0.2,0.8,0.6,0.4,0.2,0.4,0.6,0.4,0,0.2,0.2,1,0.4,0.2,0.5,0.25,0.5);
@valuesA2=(0.2,0,0.4,0.2,0.2,0.4,0,0.2,0.2,0.4,0.2,0,0.2,0.4,0.2,0.4,0,0.2,0,0,0.25,0);
@valuesC2=(0,0.4,0.4,0.4,0.2,0.2,0,0,0,0.2,0.2,0.4,0.4,0.2,0.2,0.2,0,0.4,0.6,0,0.25,0);
@valuesG2=(0.2,0.2,0.2,0.4,0,0.2,0.2,0.2,0.4,0.2,0.2,0,0,0.4,0.4,0.2,0,0,0.2,0.5,0.25,0.5);

$cutoffvalue3=4.0;
@valuesU3=(0,0.333333333,0.166666667,0,0.166666667,0,0.166666667,0.5,0,0.166666667,0.5,0.333333333,0,0.166666667,0.166666667,0.166666667,0.666666667,0.333333333,0.166666667,0.666666667,0.2,1);
@valuesA3=(0.666666667,0.333333333,0.333333333,0.333333333,0.166666667,0.666666667,0.333333333,0,0.333333333,0.333333333,0.166666667,0.166666667,0,0.333333333,0.666666667,0.333333333,0.333333333,0.166666667,0.166666667,0,0.2,0);
@valuesC3=(0.166666667,0.166666667,0.333333333,0.166666667,0.5,0,0.333333333,0.5,0,0.333333333,0.333333333,0.166666667,0,0.333333333,0,0.166666667,0,0.166666667,0.333333333,0.166666667,0.2,0);
@valuesG3=(0.166666667,0.166666667,0.166666667,0.5,0.166666667,0.333333333,0.166666667,0,0.666666667,0.166666667,0,0.333333333,1,0.166666667,0.166666667,0.333333333,0,0.333333333,0.333333333,0.166666667,0.4,0);


$hits=0;
$scannednt=0;

&openfiles;

while ($line=<DATA>){
    if ($line=~/^>([A-Za-z0-9 |]+)/) {
	 
	@possiblehits=();
	&showlocations();
        $id=$1;
	print TEMPFILE $line; 
	$hitsresume=$hits+1;
	print OUT "\nNow scanning entry: $id### starting with hit: $hitsresume\n";
	&openandcloseall;
	$seq='';
        do {                           
	    chomp($nextline=<DATA>);
	    $nextline=lc($nextline) if (!($nextline=~/^XXX/));
	    $seq=join ('',$seq,$nextline) if (!($nextline=~/^XXX/));    
        } until ($nextline=~m/^XXX/);
	$seq=~s/t/u/g;
	$seq=~s/[^aguc]/n/g;
	@gen=split ("",$seq);
	$seqlen=@gen;
	@hitat=();
	$plus=1; 
	&mainsearch();
	&newotherstrand();
	$plus=0; 
	
	&mainsearch();
	
	&clusterdetect;
    }
}
&showlocations();
print "\n\nScanned nucl.: $scannednt\n\n";



################# Start of the main search routine of the program ######################
sub mainsearch () {
    for ($count1=25;$count1<@gen-100;$count1++){ 
        $scannednt++;     
        print "nt: $scannednt\n" if ($scannednt%1000==0);       
        $pass=0;
        $knockout=1;    
        $sumpoints=0;
        $sumpoints1=0;
        $sumpoints2=0;
        $sumpoints3=0;
        @matrixseq=();
        @matrixseq1=();
        @matrixseq2=();
        @matrixseq3=();
        for ($count2=0;$count2<=20;$count2++) { 
	    $sumpoints1=$sumpoints1+($valuesA1[$count2]**$exponent) if ($gen[$count1+$count2] eq 'a'); 
	    $sumpoints1=$sumpoints1+($valuesC1[$count2]**$exponent) if ($gen[$count1+$count2] eq 'c');
	    $sumpoints1=$sumpoints1+($valuesG1[$count2]**$exponent) if ($gen[$count1+$count2] eq 'g');
	    $sumpoints1=$sumpoints1+($valuesU1[$count2]**$exponent) if ($gen[$count1+$count2] eq 'u');
	    push @matrixseq1,$gen[$count1+$count2]; 
        } 
        for ($count2=0;$count2<=20;$count2++) { 
	    $sumpoints2=$sumpoints2+($valuesA2[$count2]**$exponent) if ($gen[$count1+$count2] eq 'a'); 
	    $sumpoints2=$sumpoints2+($valuesC2[$count2]**$exponent) if ($gen[$count1+$count2] eq 'c');
	    $sumpoints2=$sumpoints2+($valuesG2[$count2]**$exponent) if ($gen[$count1+$count2] eq 'g');
	    $sumpoints2=$sumpoints2+($valuesU2[$count2]**$exponent) if ($gen[$count1+$count2] eq 'u');
	    push @matrixseq2,$gen[$count1+$count2]; 
        }
        for ($count2=0;$count2<=20;$count2++) { 
	    $sumpoints3=$sumpoints3+($valuesA3[$count2]**$exponent) if ($gen[$count1+$count2] eq 'a'); 
	    $sumpoints3=$sumpoints3+($valuesC3[$count2]**$exponent) if ($gen[$count1+$count2] eq 'c');
	    $sumpoints3=$sumpoints3+($valuesG3[$count2]**$exponent) if ($gen[$count1+$count2] eq 'g');
	    $sumpoints3=$sumpoints3+($valuesU3[$count2]**$exponent) if ($gen[$count1+$count2] eq 'u');
	    push @matrixseq3,$gen[$count1+$count2]; 
        }
	
        if ($sumpoints1>=$cutoffvalue1){
            @matrixseq=@matrixseq1;
            $pass=1;
            $sumpoints=$sumpoints1;
            $cutoffvalue=$cutoffvalue1;
        }
        if ($sumpoints2>=$cutoffvalue2){
            @matrixseq=@matrixseq2;
            $pass=2;
            $sumpoints=$sumpoints2;
            $cutoffvalue=$cutoffvalue2;
        }
        if ($sumpoints3>=$cutoffvalue3){
            @matrixseq=@matrixseq3;
            $pass=3;
            $sumpoints=$sumpoints3;
            $cutoffvalue=$cutoffvalue3;
        } 	    
        

        if ($pass>0) { 
            $string=substr($seq,$count1-$fiveprimestartbefore,$fiveprimeendafter); 
            $structure=$string;
            $min_en=RNA::fold($string,$structure);    
           
            $knockout=0 if ($min_en>$min_en_cutoff);
           
            if ($knockout==1) {     
            @struct=split('',$structure);
            @stringarr=split('',$string);
            $correctstem=1;
            $klammer1=0;
            $bulge1=0;
            for ($count3=$fiveprimestartbefore;$count3<=$fiveprimestartbefore+20;$count3++){ 
                $correctstem=0 if ($struct[$count3] eq ')');
                $klammer1++ if ($struct[$count3] eq '(');
                $bulge1++ if ($struct[$count3] eq '.');
            }
            $knockout=0 if ($klammer1<15);
            }
            
            if ($knockout==1){ 
            $unbranched=0;
            $count4=$fiveprimestartbefore;
            $klammer2auf=0;
            $klammer2zu=0;
            $klammer2firstopen=-1;   
            $klammer2lastopen=-1;   
            $klammer2lastclosed=-1;
            while ($struct[$count4]=~/[(.]/){    
                $klammer2auf++ if ($struct[$count4] eq '(');
                $klammer2firstopen=$count4 if ($struct[$count4] eq '(');
                if ($count4>=0) {$count4--;}
                else {last;}
            }
            $count4=$fiveprimestartbefore+1;
            while ($struct[$count4]=~/[(.]/){
                $klammer2auf++ if ($struct[$count4] eq '(');
                $klammer2lastopen=$count4 if ($struct[$count4] eq '(');
                if ($count4<@struct-1) {$count4++}
                else {last;}
            }
            while ($struct[$count4]=~/[).]/){
                $klammer2zu++ if ($struct[$count4] eq ')');
                $klammer2lastclosed=$count4 if ($struct[$count4] eq ')');
                if ($count4<@struct-1){$count4++}
                else {last;}
            }
            $unbranched=1 if ($klammer2auf==$klammer2zu);
            $knockout=0 if ($unbranched==0);
            $knockout=0 if ($klammer2firstopen==-1); 
            $knockout=0 if ($klammer2lastopen<=34); 
            }
            
            
            if ($knockout==1) {
            $amountofUs=0;
            $amountofAs=0;
            $amountofCs=0;
            $amountofGs=0;
            $totalnt=0;
            for ($count5=$klammer2firstopen;$count5<=$klammer2lastclosed;$count5++){
                $amountofUs++ if ($stringarr[$count5] eq 'u');
                $amountofAs++ if ($stringarr[$count5] eq 'a');
                $amountofCs++ if ($stringarr[$count5] eq 'c');
                $amountofGs++ if ($stringarr[$count5] eq 'g');
                $totalnt++;
            }
            $ratioU=$amountofUs/$totalnt;
            $ratioA=$amountofAs/$totalnt;
            $ratioC=$amountofCs/$totalnt;
            $ratioG=$amountofGs/$totalnt;
            $knockout=0 if ($ratioU<0.12 || $ratioA<0.12 || $ratioC<0.12 || $ratioG<0.12);
            }
               
            if ($knockout==1) {         
            
		push @hitat,$count1;            
		$hits++;
		print OUT "\nPLUSSTRAND!!!!!!!!" if ($plus==1);
	    	if ($plus==0){
		    $relativeposition=$seqlen-$count1;
		    print OUT "\nMINUSSTRAND!!!!!!! Relative position to the Mainstrand: $relativeposition/$seqlen";
		}
		push @possiblehits,$count1 if ($plus==1); 
		push @possiblehits,$relativeposition if ($plus==0); 
		
		print OUT "\nHit-Nr: $hits Points: $sumpoints/$cutoffvalue Pos: $count1/$seqlen Min_en:$min_en\n$id: Klammer1:$klammer1  Us: $amountofUs ratioU: $ratioU ratioA: $ratioA ratioC: $ratioC ratioG: $ratioG\n";        
		print OUT "Klammer2firstopen: $klammer2firstopen || Klammer2lastopen $klammer2lastopen || Klammer2lastclosed: $klammer2lastclosed\n";           
		print OUT "$structure\n";
		print OUT "$string\n";
		$matr=join('',@matrixseq);
		print OUT "               $matr\n";
		print EXCEL "\n$id;5;";
		print EXCEL "+;" if ($plus==1);
		print EXCEL "-;" if ($plus==0);
		print EXCEL "$hits;$count1;$min_en;";
            }  
        }
       
        if ($pass>0) { 
	    $string=substr($seq,$count1-$threeprimestartbefore,$threeprimeendafter); 
            $structure=$string;
            $min_en=RNA::fold($string,$structure);    
            
	    $knockout=1;
            $knockout=0 if ($min_en>$min_en_cutoff);
            
            if ($knockout==1) {    
		@struct=split('',$structure);
		@stringarr=split('',$string);
		$threecorrectstem=1;
		$threeklammer1=0;
		$threebulge1=0;
		for ($count3=$threeprimestartbefore;$count3<=$threeprimestartbefore+20;$count3++){ 
		    $threecorrectstem=0 if ($struct[$count3] eq '(');
		    $threeklammer1++ if ($struct[$count3] eq ')');
		    $threebulge1++ if ($struct[$count3] eq '.');
		}
		$knockout=0 if ($threeklammer1<15); 
            }
            
            if ($knockout==1){ 
            $threeunbranched=0;
            $count4=$threeprimestartbefore;
            $threeklammer2auf=0;
            $threeklammer2zu=0;
            $threeklammer2firstclosed=-1;   
            
            $threeklammer2lastclosed=-1;
            $threeklammer2firstopen=-1;
            while ($struct[$count4]=~/[).]/){    
                $threeklammer2zu++ if ($struct[$count4] eq ')');
                $threeklammer2firstclosed=$count4 if ($struct[$count4] eq ')');
                if ($count4>=0) {$count4--;}
                else {last;}
            }
            $count4=$threeprimestartbefore+1;
            while ($struct[$count4]=~/[).]/){
                $threeklammer2zu++ if ($struct[$count4] eq ')');
                $threeklammer2lastclosed=$count4 if ($struct[$count4] eq ')');
                if ($count4<@struct-1) {$count4++}
                else {last;}
            }
            $count4=$threeklammer2firstclosed-1;
            while ($struct[$count4]=~/[(.]/){
                $threeklammer2auf++ if ($struct[$count4] eq '(');
                $threeklammer2firstopen=$count4 if ($struct[$count4] eq '(');
                if ($count4>0){$count4--}
                else {last;}
            }
            $threeunbranched=1 if ($threeklammer2auf==$threeklammer2zu);
            $knockout=0 if ($threeunbranched==0);
            $knockout=0 if ($threeklammer2firstclosed==-1); 
            $knockout=0 if ($threeklammer2firstclosed>64); 
            }
           
            if ($knockout==1) {
            $amountofUs=0;
            $amountofAs=0;
            $amountofCs=0;
            $amountofGs=0;
            $totalnt=0;
            for ($count5=$klammer2firstopen;$count5<=$klammer2lastclosed;$count5++){
                $amountofUs++ if ($stringarr[$count5] eq 'u');
                $amountofAs++ if ($stringarr[$count5] eq 'a');
                $amountofCs++ if ($stringarr[$count5] eq 'c');
                $amountofGs++ if ($stringarr[$count5] eq 'g');
                $totalnt++;
            }
            $ratioU=$amountofUs/$totalnt;
            $ratioA=$amountofAs/$totalnt;
            $ratioC=$amountofCs/$totalnt;
            $ratioG=$amountofGs/$totalnt;
            $knockout=0 if ($ratioU<0.12 || $ratioA<0.12 || $ratioC<0.12 || $ratioG<0.12);
            } 
            if ($knockout==1) {         
           
		push @hitat,$count1;
		$hits++;
		print OUT "\n3333333333333333333333333";		
		print OUT "\nPLUSSTRAND!!!!!!!!" if ($plus==1);
		if ($plus==0){ 
		    $relativeposition=$seqlen-$count1;
		    print OUT "\nMINUSSTRAND!!!!!!! Relative position to the Mainstrand: $relativeposition/$seqlen";
		}
		push @possiblehits,$count1 if ($plus==1); 
		push @possiblehits,$relativeposition if ($plus==0);
		
		print OUT "\nHit-Nr: $hits Points: $sumpoints/$cutoffvalue Pos: $count1/$seqlen Min_en:$min_en\n$id: Klammer1:$threeklammer1  Us: $amountofUs ratioU: $ratioU ratioA: $ratioA ratioC: $ratioC ratioG: $ratioG\n";        
		print OUT "Klammer2firstclosed: $threeklammer2firstclosed || Klammer2lastclosed $threeklammer2lastclosed || Klammer2firstopen: $threeklammer2firstopen\n";           
		print OUT "$structure\n";
		print OUT "$string\n";
		$matr=join('',@matrixseq);
		print OUT "                                                                $matr\n";
		print EXCEL "\n$id;3;";
		print EXCEL "+;" if ($plus==1);
		print EXCEL "-;" if ($plus==0);
		print EXCEL "$hits;$count1;$min_en;";
            }  
        }    
      
    }    
}

sub showlocations {
    
    my $numberofhits=@hitat;    
    if ($numberofhits>1) { 
	$temp=-1;
	print OUT "\n***Distance between hits: ";
	foreach my $hit (@hitat) {
	    if ($temp>-1) { 
		my $diff=$hit-$temp;
		print OUT " $diff ";
	    }
	    $temp=$hit;
	}
	print OUT "\n";
    }
}

sub otherstrand {
    
    $other= join ('',reverse @gen); 
    $other=~s/c/G/g;
    $other=~s/g/C/g;
    $other=~s/a/U/g; 
    $other=~s/u/A/g;
    #@othergen=split ('',lc $other); 
    $seq=lc $other;  
   
}



sub newotherstrand {
   
    $seq= join ('',reverse @gen); 
    $seq=~s/c/G/g;
    $seq=~s/g/C/g; 
    $seq=~s/a/U/g; 
    $seq=~s/u/A/g;
    $seq= lc ($seq);
    @gen=split ('', $seq); 
   

} 


sub openfiles {
 
    if (defined $ARGV[1]) {    
	system("rm -f $ARGV[0].temp") if ($ARGV[1] eq 'rt'); 
    }
    
    $tempfilepresent=1;
    open (TEMPFILE,"$ARGV[0].temp") or $tempfilepresent=0;
    if ($tempfilepresent==1) {
	
	open (DATA,$ARGV[0]) || die "Can't open the data-file !!";
	open (EXCEL,">>$ARGV[0].excelout") or die "Cannot add lines to $ARGV[0].excelout";
	open (POSHITS,">>$ARGV[0].poshits");
	
	@tempfileentries=();
	while ($templine=<TEMPFILE>){
	    push @tempfileentries,$templine;
	}
	$lastfinishedline=$tempfileentries[@tempfileentries-2]; 
	
	
	close TEMPFILE;
	open (TEMPFILE,">>$ARGV[0].temp");
	
		
	
	
	while ($line=<DATA>) { 
	    last if ($lastfinishedline eq $line);    
	}

	
	%entryhits=();	
	open (OUT,"$ARGV[0].out") or die "Cannot open $ARGV[0].out for counting the hits";
    	while ($numhitsline=<OUT>){
	    $entryhits{$1}=$2 if ($numhitsline=~/^Now scanning entry: ([A-Za-z0-9 |]+)### starting with hit: ([0-9]+)/);  
	}
	$lastline=$tempfileentries[@tempfileentries-1];
	@tempfileentries=(); 	
	chomp ($lastline);
	$lastline=~s/>//;
	$oldnumberofhits=$entryhits{$lastline};
	print "Starting at: $oldnumberofhits bzw $entryhits{$lastline}\n";
	$hits=$oldnumberofhits-1;
	close OUT;
	open (OUT,">>$ARGV[0].out") or die "Cannot add lines to the $ARGV[0].out";
	

	print OUT "\n\n\n\n\n-----------------------------------------------------------------";
	print OUT "\n---------------------Okay, will last now!------------------------";
	print OUT "\n--Please take care that some of the next hits might be the ------";
	print OUT "\n--same as some above !! ------ Thanx ----------------------------";
	print OUT "\n-----------------------------------------------------------------\n\n\n\n";
	print OUT "-----Resuming at hitnumber: $oldnumberofhits -----\n";
    } 
    else {
	open (DATA,$ARGV[0]) || die "Can't open the data-file !!";
	open (EXCEL,">$ARGV[0].excelout") or die "Cannot create $ARGV[0].excelout";
	open (OUT,">$ARGV[0].out") or die "Cannot create $ARGV[0].out";
	open (TEMPFILE,">$ARGV[0].temp");
	open (POSHITS,">$ARGV[0].poshits");
    }
}

sub openandcloseall {			
    close TEMPFILE;	    		
    open (TEMPFILE,">>$ARGV[0].temp");	
    close OUT;
    open (OUT,">>$ARGV[0].out");
    close EXCEL;
    open (EXCEL,">>$ARGV[0].excelout");
    close POSHITS;
    open (POSHITS,">>$ARGV[0].poshits");
}

sub clusterdetect {
    @poshitssor = sort { $a <=> $b } @possiblehits;
   
    for ($poshitcount=0;$poshitcount<@poshitssor-1;$poshitcount++) {
	$pshtcnt2=$poshitcount+1;
	$over40under1000=1;
	$under40=0;
			
	while ((($poshitssor[$pshtcnt2] - $poshitssor[$poshitcount])<=1000) && $pshtcnt2<=@poshitssor-1) { 
								            
	    if (($poshitssor[$pshtcnt2]-$poshitssor[$pshtcnt2-1])>40) {
		$over40under1000++;
	    }
	    else {
		$under40++;
	    }
	    $pshtcnt2++;
	}
	
	if ($over40under1000>=3) {
	    
	    print POSHITS "\n$id\nat: ";
	    for ($printout=$poshitcount;$printout<=$poshitcount+$over40under1000+$under40-1;$printout++){
		print POSHITS "$poshitssor[$printout] ";
	    }
	    print POSHITS "\n";
	}
    }   
    
}
